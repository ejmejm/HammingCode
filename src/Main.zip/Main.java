import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Main {
    public static void main(String[] args) {
        int c;
        String in = "in.txt";
        String out = "out.txt";
        try {
            FileOutputStream os = new FileOutputStream(in, false);
            while((c=System.in.read()) != -1) {
                os.write(c);
            }
            os.close();
            Hamming.encode_7_4(in, out);
            FileInputStream is = new FileInputStream(out);
            while((c=is.read()) != -1) {
                System.out.write(c);
            }
            is.close();
            System.out.flush();
        }
        catch(Exception e) {
 
        }
    }
}
